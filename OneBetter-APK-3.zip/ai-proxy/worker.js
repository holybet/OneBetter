// Proxy de IA para a OneBetter (Cloudflare Workers). A chave da IA fica aqui, nunca na app.
// Variáveis (Settings → Variables and Secrets): GEMINI_API_KEY (secret), APP_TOKEN (secret), GEMINI_MODEL (opcional).
const SYSTEM = 'És o assistente da app OneBetter, de evolução pessoal. Responde em português, com no máximo 120 palavras, de forma clara e prática. ' +
  'Ajuda a escolher prioridades, dividir tarefas, reduzir sobrecarga e criar hábitos pequenos. Não faças diagnósticos médicos ou psicológicos, ' +
  'não prometas resultados e não culpes a pessoa. Se faltar informação, faz no máximo uma pergunta.';
export default {
  async fetch(req, env) {
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type,X-App-Token', 'Access-Control-Allow-Methods': 'POST,OPTIONS' };
    const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } });
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'POST') return json({ error: 'método não permitido' }, 405);
    if (!env.APP_TOKEN || req.headers.get('X-App-Token') !== env.APP_TOKEN) return json({ error: 'não autorizado' }, 401);
    let b; try { b = await req.json(); } catch { return json({ error: 'pedido inválido' }, 400); }
    const message = String(b.message || '').slice(0, 500);
    if (!message) return json({ error: 'mensagem vazia' }, 400);
    const c = b.context || {};
    const ctx = `Minutos planeados hoje: ${Number(c.plannedMin) || 0}. Minutos disponíveis: ${Number(c.availMin) || 0}. Objetivos ativos: ${Number(c.activeGoals) || 0}.`;
    const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [{ role: 'user', parts: [{ text: ctx + '\nPergunta: ' + message }] }], generationConfig: { maxOutputTokens: 400, temperature: 0.6 } })
    });
    if (!r.ok) return json({ error: 'serviço de IA indisponível (' + r.status + ')' }, 502);
    const j = await r.json();
    const reply = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    return reply ? json({ reply }) : json({ error: 'sem resposta' }, 502);
  }
};
