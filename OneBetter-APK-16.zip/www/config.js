// Configuração opcional da OneBetter. Nada aqui é segredo de servidor.
// Preenche uma vez e todos os utilizadores da tua versão ficam com isto ativo.
window.ONEBETTER = {
  // Firebase (Definições do projeto → As tuas apps → Web → firebaseConfig). Exemplo:
  // firebase: { apiKey: "...", authDomain: "...", projectId: "...", appId: "..." },
  firebase: null,
  // true = só se entra com conta (sem a opção "usar só neste dispositivo").
  requireLogin: false,
  // Chave TMDB (v3 api_key ou "API Read Access Token"). Fica visível a quem abrir a app: usa só em projeto pessoal/não comercial.
  tmdbKey: "",
  // Endereço do teu serviço de IA (ver ai-proxy/README). Dá IA a todos os utilizadores com sessão iniciada.
  aiUrl: ""
};
