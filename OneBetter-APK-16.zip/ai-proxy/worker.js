// Serviço de IA da OneBetter (Cloudflare Workers, plano gratuito).
// A chave do Gemini fica SÓ aqui. A app envia o token de login do Firebase; o Worker confirma quem é
// e limita os pedidos por pessoa e por dia, para ninguém gastar a tua quota.
//
// Configuração (Settings > Variables and Secrets):
//   GEMINI_API_KEY      (secret)  chave do Google AI Studio
//   FIREBASE_PROJECT_ID (texto)   ex.: onebetter-8d8c6
//   DAILY_LIMIT         (opcional) pedidos por pessoa por dia, por omissão 30
//   GLOBAL_LIMIT        (opcional) pedidos totais por dia, por omissão 1500
//   GEMINI_MODEL        (opcional) por omissão gemini-2.5-flash
// Ligação KV (Settings > Bindings > KV namespace): nome da variável RATE
const JWK_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
let jwkCache = { at: 0, keys: [] };
const b64 = s => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(s.length / 4) * 4, '=')), c => c.charCodeAt(0));
const txt = s => new TextDecoder().decode(b64(s));

async function verify(token, pid) {
  const [h, p, s] = String(token).split('.');
  if (!h || !p || !s) throw new Error('token inválido');
  const hd = JSON.parse(txt(h)), pl = JSON.parse(txt(p));
  if (hd.alg !== 'RS256') throw new Error('algoritmo');
  if (Date.now() - jwkCache.at > 3600e3 || !jwkCache.keys.some(k => k.kid === hd.kid)) {
    const r = await fetch(JWK_URL); jwkCache = { at: Date.now(), keys: (await r.json()).keys || [] };
  }
  const jwk = jwkCache.keys.find(k => k.kid === hd.kid); if (!jwk) throw new Error('chave desconhecida');
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64(s), new TextEncoder().encode(h + '.' + p));
  const now = Math.floor(Date.now() / 1000);
  if (!ok || pl.aud !== pid || pl.iss !== 'https://securetoken.google.com/' + pid || pl.exp < now || !pl.sub) throw new Error('token recusado');
  return pl.sub;
}

export default {
  async fetch(req, env) {
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type,Authorization', 'Access-Control-Allow-Methods': 'POST,OPTIONS' };
    const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } });
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (req.method !== 'POST') return json({ error: 'método não permitido' }, 405);
    if (!env.GEMINI_API_KEY || !env.FIREBASE_PROJECT_ID) return json({ error: 'serviço mal configurado' }, 500);
    let uid;
    try { uid = await verify((req.headers.get('Authorization') || '').replace(/^Bearer /, ''), env.FIREBASE_PROJECT_ID); }
    catch (e) { return json({ error: 'não autorizado' }, 401); }
    let b; try { b = await req.json(); } catch { return json({ error: 'pedido inválido' }, 400); }
    const a = b.agent;
    if (!a || !Array.isArray(a.contents) || !a.systemInstruction) return json({ error: 'pedido inválido' }, 400);
    const contents = a.contents.slice(-12);
    if (JSON.stringify(contents).length + JSON.stringify(a.systemInstruction).length > 60000) return json({ error: 'pedido demasiado grande' }, 413);
    // limites por pessoa e globais
    if (env.RATE) {
      const day = new Date().toISOString().slice(0, 10), ku = `u:${uid}:${day}`, kg = `g:${day}`;
      const [cu, cg] = await Promise.all([env.RATE.get(ku), env.RATE.get(kg)]);
      if ((+cu || 0) >= (+env.DAILY_LIMIT || 30)) return json({ error: 'limite diário atingido' }, 429);
      if ((+cg || 0) >= (+env.GLOBAL_LIMIT || 1500)) return json({ error: 'serviço cheio hoje, tenta amanhã' }, 429);
      await Promise.all([env.RATE.put(ku, String((+cu || 0) + 1), { expirationTtl: 172800 }), env.RATE.put(kg, String((+cg || 0) + 1), { expirationTtl: 172800 })]);
    }
    const g = a.generationConfig || {};
    const gen = { temperature: Math.min(+g.temperature || 0.5, 1), maxOutputTokens: 1200, responseMimeType: 'application/json' };
    if (g.thinkingConfig) gen.thinkingConfig = { thinkingBudget: 0 };
    const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: a.systemInstruction, contents, generationConfig: gen })
    });
    return new Response(await r.text(), { status: r.status, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
};
