# IA para todos os utilizadores (serviço teu, gratuito para começar)

A chave da IA fica no Cloudflare, nunca na app. Só quem tem sessão iniciada na OneBetter pode usar, e há um limite por pessoa e por dia.

## Passos (dá para fazer no telemóvel)
1. **Chave:** aistudio.google.com/apikey → Create API key → copia.
2. **Worker:** dash.cloudflare.com → Workers & Pages → Create → Worker → Deploy → Edit code → apaga tudo, cola o conteúdo de `worker.js` → Deploy.
3. **Memória dos limites (KV):** Storage & Databases → KV → Create namespace (nome `onebetter-rate`). Depois, no Worker: Settings → Bindings → Add → KV namespace → nome da variável `RATE` → escolhe o namespace → Deploy.
4. **Variáveis:** no Worker, Settings → Variables and Secrets:
   - `GEMINI_API_KEY` (tipo Secret) = a chave do passo 1
   - `FIREBASE_PROJECT_ID` (tipo Text) = `onebetter-8d8c6`
   - opcional `DAILY_LIMIT` = pedidos por pessoa por dia (padrão 30)
   - opcional `GLOBAL_LIMIT` = pedidos totais por dia (padrão 1500)
5. Copia o endereço do Worker (`https://nome.conta.workers.dev`) e põe-no no `config.js` da raiz do repositório, na linha `aiUrl: "..."`. Na compilação seguinte, todos os utilizadores têm a IA incluída.

## Custos e limites (confirma sempre os valores atuais)
- Cloudflare Workers e KV têm plano gratuito (ver developers.cloudflare.com/workers/platform/pricing).
- A chave gratuita do Gemini tem limites de pedidos por minuto e por dia **partilhados por todos os utilizadores** (ai.google.dev/gemini-api/docs/rate-limits). Com muitos utilizadores, o limite esgota-se: ajusta `DAILY_LIMIT`/`GLOBAL_LIMIT` ou ativa a faturação no Google AI Studio.
- Cada pedido envia a agenda, hábitos e objetivos da pessoa ao Google Gemini (com o consentimento dela na app). Refere isto na tua política de privacidade se publicares a app.
