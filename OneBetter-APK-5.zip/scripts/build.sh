#!/usr/bin/env bash
# Compila o APK. Corre a partir de qualquer pasta.
set -euxo pipefail
cd "$(dirname "$0")/.."
npm install --no-audit --no-fund
# Google no APK: só se colocares google-services.json na raiz do projeto (ver README)
if [ -f google-services.json ]; then
  npm install --no-audit --no-fund @capacitor-firebase/authentication@^6 firebase@^10
fi
npx cap add android
cp -r assets/android-res/. android/app/src/main/res/
rm -rf android/app/src/main/res/mipmap-anydpi-v26
# Permissões de alarme e notificações
M=android/app/src/main/AndroidManifest.xml
for P in POST_NOTIFICATIONS VIBRATE WAKE_LOCK SCHEDULE_EXACT_ALARM USE_EXACT_ALARM RECEIVE_BOOT_COMPLETED USE_FULL_SCREEN_INTENT; do
  grep -q "android.permission.$P" "$M" || sed -i "s#</manifest>#    <uses-permission android:name=\"android.permission.$P\"/>\n</manifest>#" "$M"
done
if [ -f google-services.json ]; then cp google-services.json android/app/google-services.json; fi
npx cap sync android
# Chave de debug fixa: o APK mantém sempre a mesma assinatura (atualiza por cima sem perder dados)
mkdir -p ~/.android && cp assets/debug.keystore ~/.android/debug.keystore
cd android
chmod +x gradlew
./gradlew assembleDebug --stacktrace
ls -l app/build/outputs/apk/debug/
