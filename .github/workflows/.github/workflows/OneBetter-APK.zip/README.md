# OneBetter — APK

Pequenas ações, grandes resultados.

A app é `www/index.html` (HTML/JS único, dados locais em IndexedDB, offline) embrulhada em Android com Capacitor. Os lembretes usam notificações locais nativas, por isso funcionam com a app fechada.

## Compilar o APK só com o telemóvel

1. Cria uma conta gratuita em github.com e um repositório novo, privado, chamado `onebetter`.
2. Envia **todos** os ficheiros desta pasta para o repositório (Add file → Upload files), mantendo as pastas `www`, `assets`, `scripts` e `.github/workflows`.
   - Se o navegador não deixar enviar a pasta `.github`, usa Add file → Create new file e escreve o nome `.github/workflows/build-apk.yml`, colando o conteúdo do ficheiro.
3. Separador **Actions** → "Compilar APK OneBetter" → **Run workflow**. Demora cerca de 5–8 minutos.
4. Quando ficar verde, abre a execução → **Artifacts** → `OneBetter-APK` (é um .zip).
5. Extrai o .zip (app Ficheiros da Samsung) e abre `app-debug.apk` para instalar. Permite "instalar de fontes desconhecidas" quando pedido.
6. Ao abrir, aceita a permissão de notificações.

## Notas

- O APK de debug é assinado automaticamente, por isso não dá "pacote inválido" por falta de assinatura.
- Se o Android recusar por já haver outra versão, desinstala a anterior e instala de novo (os dados locais perdem-se; exporta antes em Definições).
- Para alarmes fiáveis, em Definições do Android → Apps → OneBetter → Bateria, escolhe "Sem restrições".
- Para atualizar a app, edita `www/index.html` no repositório e volta a correr o workflow.
