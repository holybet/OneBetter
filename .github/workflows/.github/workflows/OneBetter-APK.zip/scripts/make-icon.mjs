// Converte assets/icon.svg em assets/icon-only.png (1024x1024) para o @capacitor/assets
import sharp from 'sharp';
await sharp('assets/icon.svg').resize(1024, 1024).png().toFile('assets/icon-only.png');
console.log('icon-only.png criado');
